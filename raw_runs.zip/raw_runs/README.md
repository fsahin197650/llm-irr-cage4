# raw_runs

One JSON file per training run: `<learner>/<tier>/<method>/seed_<n>.json`.

- `strong_ppo/` — 240 runs (8 methods × 10 seeds × 3 tiers). Every reported result.
- `weak_legacy/` — 270 runs (9 methods × 10 seeds × 3 tiers). The superseded learner,
  kept because Figures 2 and 3 document the spurious structure it produces.

Tier folders are named by episode horizon; the `env` field inside each file keeps the
original config key, so provenance is preserved: H50 = `cage2`, H100 = `cage4`,
H200 = `cyborgpp`. All three are the same CAGE-4 enterprise scenario at 50 / 100 / 200 steps.

## Fields

| key | meaning |
|---|---|
| `method` | reward design under test |
| `env` | internal tier key (see mapping above) |
| `seed` | random seed |
| `stats` | per-run aggregates — `mean_n_compromised` is the paper's primary metric (lower is better) |
| `stats.learner` | present (= 1.0) only for strong-PPO runs; absent for legacy runs |
| `final_reward_design` | the reward actually used, as emitted by the LLM (or the fixed baseline) |
| `n_iterations` | reward-refinement iterations actually run |
| `llm_failures` | LLM calls that failed and fell back; **0 in every published run** |
| `elapsed_seconds` | wall-clock training time |

## Loading

```python
import json, pathlib
runs = [json.loads(p.read_text()) for p in
        pathlib.Path("strong_ppo/H200").rglob("seed_*.json")]
print(len(runs), runs[0]["stats"]["mean_n_compromised"])
```

`../tables/all_runs_long.csv` is the same data flattened to one row per run.
