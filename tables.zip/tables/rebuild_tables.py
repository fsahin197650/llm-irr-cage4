#!/usr/bin/env python3
"""Rebuild every table in this folder from ../raw_runs/ — no other input needed.

    python rebuild_tables.py            # writes the CSVs next to this script
    python rebuild_tables.py --check    # recompute and diff against the shipped CSVs

Requires only numpy (for the bootstrap). Everything else is the standard library.
"""
from __future__ import annotations

import argparse
import csv
import json
import statistics as st
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
RAW = HERE.parent / "raw_runs"

TIERS = {"H50": 50, "H100": 100, "H200": 200}
METHOD_LABEL = {
    "sme_baseline": "SME Baseline", "pure_marl": "Pure MARL", "eureka": "EUREKA",
    "card": "CARD", "hmarl": "H-MARL", "llm_irr_legacy": "LLM-IRR Legacy",
    "llm_irr_1a": "LLM-IRR +C1", "llm_irr_1ab": "LLM-IRR +C1C2",
    "llm_irr_full": "LLM-IRR Full (C1+C2+C3)",
}
METRICS = ["mean_n_compromised", "mean_clean_ratio", "mean_min_clean_ratio"]
BEH = ["mean_investigate_ratio", "mean_isolate_ratio", "mean_recover_ratio"]


def load(tree: str, tier: str) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    base = RAW / tree / tier
    for mdir in sorted(p for p in base.iterdir() if p.is_dir()):
        rows = []
        for f in sorted(mdir.glob("seed_*.json")):
            j = json.loads(f.read_text(encoding="utf-8"))
            rows.append({"seed": j["seed"], **j["stats"]})
        out[mdir.name] = rows
    return out


def boot_ci(vals, n_boot: int = 5000, seed: int = 0):
    """Bootstrap mean + percentile 95% CI. seed=0 fixed, so this is deterministic."""
    v = np.asarray([x for x in vals if x is not None], float)
    if len(v) < 2:
        return (float(v[0]),) * 3 if len(v) else (float("nan"),) * 3
    rng = np.random.default_rng(seed)
    m = v[rng.integers(0, len(v), size=(n_boot, len(v)))].mean(axis=1)
    lo, hi = np.percentile(m, [2.5, 97.5])
    return float(v.mean()), float(lo), float(hi)


def write(path: Path, header, rows, out: dict[str, str]):
    buf = [",".join(map(str, header))] + [",".join(map(str, r)) for r in rows]
    out[path.name] = "\n".join(buf) + "\n"


def build() -> dict[str, str]:
    out: dict[str, str] = {}

    for tier in TIERS:
        rows = []
        for meth, runs in load("strong_ppo", tier).items():
            cells = []
            for m in METRICS:
                cells += [f"{x:.6f}" for x in boot_ci([r.get(m) for r in runs])]
            rows.append([meth, METHOD_LABEL.get(meth, meth), len(runs)] + cells)
        write(HERE / f"T1_{tier}.csv",
              ["method", "method_label", "n_seeds"] +
              [c for m in METRICS for c in (m, m + "_lo", m + "_hi")], rows, out)

    rows = []
    for tier, horizon in TIERS.items():
        data = load("strong_ppo", tier)
        means = {m: st.fmean([r["mean_n_compromised"] for r in runs]) for m, runs in data.items()}
        sd = st.fmean([st.stdev([r["mean_n_compromised"] for r in runs]) for runs in data.values()])
        rows.append([tier, horizon, len(means), sum(len(r) for r in data.values()),
                     f"{st.fmean(means.values()):.4f}",
                     f"{max(means.values()) - min(means.values()):.4f}", f"{sd:.4f}"])
    write(HERE / "table2_horizon_summary.csv",
          ["tier", "horizon_steps", "n_methods", "n_runs", "grand_mean_n_compromised",
           "between_method_spread", "mean_within_method_seed_std"], rows, out)

    tmp = []
    for meth, runs in load("strong_ppo", "H200").items():
        mu, lo, hi = boot_ci([r["mean_n_compromised"] for r in runs])
        tmp.append((mu, meth, len(runs), lo, hi))
    rows = [[i, meth, METHOD_LABEL.get(meth, meth), n, f"{mu:.4f}", f"{lo:.4f}", f"{hi:.4f}"]
            for i, (mu, meth, n, lo, hi) in enumerate(sorted(tmp), 1)]
    write(HERE / "table3_main_comparison_H200.csv",
          ["rank", "method", "method_label", "n_seeds", "n_compromised_mean", "ci95_lo", "ci95_hi"],
          rows, out)

    rows = []
    for tier in TIERS:
        for meth, runs in load("strong_ppo", tier).items():
            vals = [st.fmean([r[b] for r in runs if r.get(b) is not None]) for b in BEH]
            rows.append([tier, meth, METHOD_LABEL.get(meth, meth)] + [f"{v:.4f}" for v in vals])
    write(HERE / "table_behavior_action_distributions.csv",
          ["tier", "method", "method_label", "investigate_ratio", "isolate_ratio", "recover_ratio"],
          rows, out)

    rows = []
    for tree in ("strong_ppo", "weak_legacy"):
        for tier, horizon in TIERS.items():
            for meth, runs in load(tree, tier).items():
                for r in runs:
                    rows.append([tree, tier, horizon, meth, METHOD_LABEL.get(meth, meth), r["seed"],
                                 r.get("mean_n_compromised"), r.get("mean_clean_ratio"),
                                 r.get("mean_min_clean_ratio"), r.get("mean_reward"),
                                 r.get("mean_investigate_ratio"), r.get("mean_isolate_ratio"),
                                 r.get("mean_recover_ratio")])
    write(HERE / "all_runs_long.csv",
          ["learner_tree", "tier", "horizon_steps", "method", "method_label", "seed",
           "n_compromised", "clean_ratio", "min_clean_ratio", "mean_reward",
           "investigate_ratio", "isolate_ratio", "recover_ratio"], rows, out)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true",
                    help="recompute and compare against the shipped CSVs instead of overwriting")
    args = ap.parse_args()

    built = build()
    if not args.check:
        for name, text in built.items():
            (HERE / name).write_text(text, encoding="utf-8")
            print(f"yazildi / written: {name}")
        return 0

    bad = 0
    for name, text in built.items():
        on_disk = (HERE / name).read_text(encoding="utf-8")
        same = on_disk.replace("\r\n", "\n") == text
        print(f"{'OK  ' if same else 'FARK'}: {name}")
        bad += not same
    print("\nTum tablolar raw_runs/ ile tutarli." if not bad else f"\n{bad} tabloda fark var.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
