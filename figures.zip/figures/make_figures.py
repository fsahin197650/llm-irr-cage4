#!/usr/bin/env python3
"""Regenerate Figures 2-6 from ../raw_runs/ — no other input needed.

    python make_figures.py            # writes into ./regenerated/
    python make_figures.py --out .    # overwrite the shipped PNGs instead

Output goes to ./regenerated/ by default so the PNGs that appear in the paper are
never silently replaced; compare the two folders to confirm reproduction.

Figure 1 (the architecture diagram) is a hand-drawn schematic, not generated from
data, so it has no counterpart here.

Requires numpy and matplotlib.
"""
from __future__ import annotations

import argparse
import json
import statistics as st
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
RAW = HERE.parent / "raw_runs"

METHOD_ORDER = ["sme_baseline", "pure_marl", "eureka", "card", "hmarl",
                "llm_irr_legacy", "llm_irr_1a", "llm_irr_1ab", "llm_irr_full"]
TIERS = ["H50", "H100", "H200"]


def load(tree: str, tier: str) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    for mdir in sorted(p for p in (RAW / tree / tier).iterdir() if p.is_dir()):
        out[mdir.name] = [json.loads(f.read_text(encoding="utf-8"))["stats"]
                          for f in sorted(mdir.glob("seed_*.json"))]
    return out


def ordered(d):
    return [m for m in METHOD_ORDER if m in d] + [m for m in d if m not in METHOD_ORDER]


def boot_ci(vals, n_boot=5000, seed=0):
    v = np.asarray([x for x in vals if x is not None], float)
    if len(v) < 2:
        return (float(v[0]),) * 3 if len(v) else (float("nan"),) * 3
    rng = np.random.default_rng(seed)
    m = v[rng.integers(0, len(v), size=(n_boot, len(v)))].mean(axis=1)
    lo, hi = np.percentile(m, [2.5, 97.5])
    return float(v.mean()), float(lo), float(hi)


def col(data, methods, key):
    return [[r.get(key) for r in data[m]] for m in methods]


def fig_null(tree, tier, label, outfile, out: Path):
    data = load(tree, tier)
    methods = ordered(data)
    stats = [boot_ci(v) for v in col(data, methods, "mean_n_compromised")]
    means = [s[0] for s in stats]
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.bar(range(len(methods)), means,
           yerr=[[m - s[1] for m, s in zip(means, stats)],
                 [s[2] - m for m, s in zip(means, stats)]],
           capsize=4, color="#4C72B0", alpha=0.85)
    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, rotation=40, ha="right", fontsize=8)
    ax.set_ylabel("n_compromised (lower = better)")
    ax.set_title(f"Security outcome by method — {label} learner, {tier}\n"
                 "(bootstrap 95% CI; LLM reward designs do NOT beat simple baselines)")
    ax.axhline(np.nanmean(means), ls="--", c="gray", lw=1,
               label=f"grand mean {np.nanmean(means):.2f}")
    ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(out / outfile, dpi=600); plt.close(fig)


def fig_two_panel(tree, tier, left_key, left_lab, left_title, sup, outfile, out: Path, stacked=False):
    data = load(tree, tier)
    methods = ordered(data)
    x = np.arange(len(methods))
    ncomp = [boot_ci(v)[0] for v in col(data, methods, "mean_n_compromised")]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 4.5))
    if stacked:
        inv, iso, rec = (
            [float(np.nanmean([y for y in v if y is not None]) or 0)
             for v in col(data, methods, k)]
            for k in ("mean_investigate_ratio", "mean_isolate_ratio", "mean_recover_ratio"))
        a1.bar(x, inv, label="investigate", color="#4C72B0")
        a1.bar(x, iso, bottom=inv, label="isolate", color="#DD8452")
        a1.bar(x, rec, bottom=np.array(inv) + np.array(iso), label="recover", color="#55A868")
        a1.legend(fontsize=8)
    else:
        a1.bar(x, [float(np.nanmean([y for y in v if y is not None]) or 0)
                   for v in col(data, methods, left_key)], color="#8172B3")
    a1.set_xticks(x); a1.set_xticklabels(methods, rotation=40, ha="right", fontsize=8)
    a1.set_ylabel(left_lab); a1.set_title(left_title)
    a2.bar(x, ncomp, color="#C44E52", alpha=0.85)
    a2.set_xticks(x); a2.set_xticklabels(methods, rotation=40, ha="right", fontsize=8)
    a2.set_ylabel("n_compromised")
    a2.set_title("Outcome IDENTICAL across methods" if stacked else "Fair metric: no real difference")
    if stacked:
        a2.set_ylim(0, max(ncomp) * 1.3)
    fig.suptitle(sup)
    fig.tight_layout(); fig.savefig(out / outfile, dpi=600); plt.close(fig)


def fig_horizon(out: Path):
    fig, axes = plt.subplots(1, len(TIERS), figsize=(5.2 * len(TIERS), 4.4), squeeze=False)
    for ax, tier in zip(axes[0], TIERS):
        data = load("strong_ppo", tier)
        methods = ordered(data)
        stats = [boot_ci(v) for v in col(data, methods, "mean_n_compromised")]
        means = [s[0] for s in stats]
        ax.bar(range(len(methods)), means,
               yerr=[[m - s[1] for m, s in zip(means, stats)],
                     [s[2] - m for m, s in zip(means, stats)]],
               capsize=3, color="#4C72B0", alpha=0.85)
        ax.set_xticks(range(len(methods)))
        ax.set_xticklabels(methods, rotation=45, ha="right", fontsize=7)
        ax.set_title(f"{tier}  (grand mean {st.fmean(means):.2f})", fontsize=10)
        ax.set_ylabel("n_compromised" if ax is axes[0][0] else "")
    fig.suptitle("Horizon panels: no method wins at any difficulty; "
                 "absolute level rises with horizon (all learner:ppo)")
    fig.tight_layout(); fig.savefig(out / "fig4_horizon_panels.png", dpi=600); plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="regenerated")
    a = ap.parse_args()
    out = (HERE / a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    fig_null("weak_legacy", "H200", "weak-legacy", "fig2_weak_learner_spurious_H200.png", out)
    fig_two_panel("weak_legacy", "H200", "mean_reward", "shaped mean_reward",
                  "Shaped reward: apparent (spurious) spread",
                  "Shaped-reward magnitude is NOT a valid cross-method comparison (H200)",
                  "fig3_shaped_reward_misleading_H200.png", out)
    fig_horizon(out)
    fig_null("strong_ppo", "H200", "strong-PPO", "fig5_main_comparison_H200.png", out)
    fig_two_panel("strong_ppo", "H200", None, "action distribution",
                  "Behavior DIFFERS across methods",
                  "C2: LLM reward steers behavior but not the security outcome (H200)",
                  "fig6_behavior_vs_outcome_H200.png", out, stacked=True)
    for p in sorted(out.glob("fig*.png")):
        print(f"yazildi / written: {p.relative_to(HERE)}")


if __name__ == "__main__":
    main()
