# Learner and experiment settings

Every method in the paper shares one learner; the reward function is the only variable.

## PPO (the "strong" learner used for all reported results)

| parameter | value |
|---|---|
| learning rate | 3.0e-4 |
| discount γ | 0.99 |
| GAE λ | 0.95 |
| clip range | 0.2 |
| epochs per update | 4 |
| batch size | 512 |
| entropy coefficient | 0.01 |
| value-function coefficient | 0.5 |
| max gradient norm | 0.5 |
| rollout (episodes per update) | 10 |
| episodes per run | 1200 |
| early stopping | patience 150, min-delta 0.5 |
| credit-to-gradient (C1 arms) | on |

## Reward-refinement loop (LLM-IRR arms)

| parameter | value |
|---|---|
| max iterations | 5 |
| min iterations | 2 |
| convergence threshold | 0.02 |
| convergence patience | 3 |
| credit mixing weight α | 0.2 |
| team weight β | 0.2 |
| LLM | `qwen2.5-coder:7b` via Ollama, temperature 0.7, JSON mode |

## Environment

CAGE-4 enterprise scenario on CybORG-4, five blue agents, active `FiniteStateRedAgent`.
Observation 210-d per agent, 242 parameterised actions per agent. The three tiers differ
only in episode horizon.

| tier | horizon | internal config key |
|---|---|---|
| H50 | 50 steps | `cage2` |
| H100 | 100 steps | `cage4` |
| H200 | 200 steps | `cyborgpp` |

## Seeds

`42, 123, 7, 2024, 1337, 99, 256, 512, 1024, 2048` — the same ten for every method and tier.

## The weak (legacy) learner

`raw_runs/weak_legacy/` was produced by the pipeline's original learner: single-step
REINFORCE (advantage = reward − batch mean; critic computed but unused; no GAE, no PPO
clipping, one epoch) over a hierarchical policy whose sub-policies were never trained.
It is included because Figures 2 and 3 document the spurious structure it produces.
Runs from the strong learner carry `stats.learner = 1.0`; legacy runs have no such key.
